<?php

session_start();
session_regenerate_id(true);

include "../database/db.php";

if( isset($_POST["submit"]) ){
    $username = $_POST["username"];    
    $password = $_POST["password"];
    $token=$_POST['csrf_token'];
    //$cookie = $_POST["remember"];
    $time = time();
    // Before Hashing
    // $query = "SELECT * FROM user WHERE name = '$username' AND password = '$password'";
    // $result = $connection->query($query);
   htmlentities($username);
   htmlentities($password);

    // After Hashing
    $query = "SELECT * FROM user WHERE name = ?";
    $stmt=$connection->prepare($query);
    $stmt->bind_param("s",$username);

    $stmt->execute();

    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    if( $row["role"]){

        if( password_verify($password,$row["password"]) ){
            $_SESSION["username"] = $username;

            if($row["role"] == "admin" ) header("Location: ../home-developer.php");
            else header("Location: ../index.php");
            die();
        }
    }
    header("Location: ../login.php");
    
}
?>