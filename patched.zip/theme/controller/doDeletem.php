<?php
include '.././database/db.php';

$id = $_GET['id'];
$query="DELETE FROM merch WHERE id=?";
$stmt=$connection->prepare($query);
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();


header("Location: ./../merch-dev.php");
?>