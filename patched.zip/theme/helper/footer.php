<footer>
				<div class="container">
					<p><a href="index.php">Home</a> | <a href="about.php">Contact Us</a> | <a href="merch.php">Store</a> | <a href="#subscribe">Subscribe</a></p>
					<div class="social">
					<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
						<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
						<a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
						
					</div>
					
					<p class="copy-right">Copyright &copy; 2020 Designed By : INDIOWEB, All rights reserved.</p>
				</div>
			</footer>