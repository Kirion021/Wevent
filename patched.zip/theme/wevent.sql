-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2020 at 12:09 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wevent`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `name`, `price`, `date`, `description`, `image`) VALUES
(1, 'Comifuro', 25000, '2020-02-22', 'The hottest anime convention at your doorstep. Time to chase those merchandises', '2.jpg'),
(2, 'Hammersonic', 30000, '2020-04-24', 'Rock n roll all night all day with bands like slipknot and more', '1.jpg'),
(3, 'Head In The clouds ', 800000, '2020-03-07', 'The hottest brand currently is having their world tour, with lineups like Rich Brian,Joji and many more.', '3.jpg'),
(4, 'A.U.S World Tour', 300000, '2020-05-30', 'Alive Until Sunset is here to show the world their music. Enjoy a new revolutionary music', '5.jpg'),
(6, 'Solo concert', 30000, '2020-05-13', 'Featuring the best artists in the world. Get your groove on!', '6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `merch`
--

CREATE TABLE `merch` (
  `id` int(20) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `merch`
--

INSERT INTO `merch` (`id`, `nama`, `price`, `image`) VALUES
(14, 'Glowsticks', 30000, 'messageImage_1588758641769.jpg'),
(15, 'Hairband', 25000, 'messageImage_1588758714404.jpg'),
(16, 'Lanyard', 25000, 'messageImage_1588758934950.jpg'),
(17, 'Card holder', 30000, 'messageImage_1588759243842.jpg'),
(18, 'Clean Towel', 30000, 'messageImage_1588759024828.jpg'),
(19, 'White bowl', 25000, 'messageImage_1588758855923.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `role` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `role`) VALUES
(2, 'root', '$2y$10$LoAmvfxpVsKylGMCHcHm1.RikoNGVW9g93/dxzbM1T/0zbmA4AQny', 'admin'),
(3, 'king', '$2y$10$i6XMCuZeHnqKPYrQ2TEJkO0kGD9OrIz8KgpKcC75Gvf3wXzvy39LG', 'admin'),
(10, 'nathan', '$2y$10$i6XMCuZeHnqKPYrQ2TEJkO0kGD9OrIz8KgpKcC75Gvf3wXzvy39LG', 'guest');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merch`
--
ALTER TABLE `merch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `merch`
--
ALTER TABLE `merch`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
