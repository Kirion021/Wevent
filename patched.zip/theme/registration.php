<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Bloger - Registration</title>
		<!-- Description, Keywords and Author -->
		<meta name="description" content="Your description">
		<meta name="keywords" content="Your,Keywords">
		<meta name="author" content="ResponsiveWebInc">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Styles -->
		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Font awesome CSS -->
		<link href="css/font-awesome.min.css" rel="stylesheet">		
		<!-- Custom CSS -->
		<link href="css/style.css" rel="stylesheet">
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="#">
	</head>
	
	<body>
	
		<div class="wrapper">
		
			<!-- header -->
			<?php include_once 'helper/header.php'; 
		if(isset($_SESSION['username'])){
			header("Location: ./index.php");
		}
		?>
			
			<!-- banner -->
			<div class="banner">
				<div class="container">
					<!-- form content / register area -->
					<div class="register-area">
						<!-- heading -->
						<h3>Sign Up, For An Account</h3>
						<form action="controller/doRegister.php" method="POST">
							<div class="form-group">
								<input type="text" required class="form-control" name="username" id="username" placeholder="Full Name">
							</div>
							
							<div class="form-group">
								<input type="email" required class="form-control" id="exampleInputEmail1" placeholder="Enter email">
							</div>
							<div class="form-group">
								<input type="password" required class="form-control" name="password" id="password" placeholder="Password">
							</div>
							<div class="form-group">
								<input type="password" required class="form-control" name= "confirm_password" id="confirm_password" placeholder="Re-Password">
							</div>
							<div class="checkbox form-group">
								<label>
									<input type="checkbox" required> I agree with all terms and conditions.
								</label>
							</div>
							<input type="submit" value="Register" name="register">
							
							
						</form>

						<a href="./login.php">Already Have An Account? Log In!</a>
					</div>
				</div>
			</div>
			<!-- banner end -->
			
			<!-- footer -->
			<?php include_once 'helper/footer.php' ?>

		</div>
		
		
		<!-- Javascript files -->
		<!-- jQuery -->
		<script src="js/jquery.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Respond JS for IE8 -->
		<script src="js/respond.min.js"></script>
		<!-- HTML5 Support for IE -->
		<script src="js/html5shiv.js"></script>
		<!-- Custom JS -->
		<script src="js/custom.js"></script>
	</body>	
</html>