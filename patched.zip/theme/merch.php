<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>WeVent</title>
		<!-- Description, Keywords and Author -->
		<meta name="description" content="Your description">
		<meta name="keywords" content="Your,Keywords">
		<meta name="author" content="ResponsiveWebInc">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Styles -->
		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Font awesome CSS -->
		<link href="css/font-awesome.min.css" rel="stylesheet">		
		<!-- Custom CSS -->
		<link href="css/style.css" rel="stylesheet">
		
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<!-- Favicon -->
		<link rel="shortcut icon" href="#">
	</head>
	
	<body>
	
		<div class="wrapper">
		
		<?php include_once 'helper/header.php'; ?>
			
			<!-- banner -->
			<div class="banner">
				<div class="container">
					<!-- heading -->
					<h2>Come see our Original and exclusive Merchandise!</h2>
					<!-- paragraph -->
					<p>Merch only for the rich</p>
				</div>
			</div>
			<!-- banner end -->
			
          
			<!-- Eveent -->
			<div class="event" id="event">
				<div class="container">
					<div class="default-heading">
						<!-- heading -->
						<h2>Upcoming Events</h2>
					</div>
					
					<div class="row">
							<?php
							include "./database/db.php";
							
   							$query="SELECT * FROM event";
      						$result=$connection->query($query);

      						while($row=$result->fetch_assoc()){
  							?>
    						<div class="col-sm-4 distance">
      						<p><b><?php echo $row['name']?> </b></p> 
      						<center>
       						<img src="/WeVent/bloger/theme/img/event/<?php echo $row['image']; ?>" class="img-responsive" alt="Image"> <!-- {image} = image from database -->
      						</center>
      						<p>Date: <?php echo $row['date']?></p> 
      						<p>Rp <?php echo $row['price']?></p> 
							<p>Desription: <?php echo $row['description']?></p> 
      						<br>
							  </div>
							  <?php } ?>
						
					</div>
				</div>
			</div>
			
			 	<!-- Merchandise -->
				 <div class="event" id="event">
				<div class="container">
					<div class="default-heading">
						<!-- heading -->
						<h2>Trending Merchandise</h2>
					</div>
					<div class="row">
					<?php  
				include "./database/db.php";
				include "./controller/doCart.php";
                $query = "SELECT * FROM merch";  
                $result=$connection->query($query);

                while($row=$result->fetch_assoc()){
                    ?>
                <div class="col-md-4">  
                     <form method="post" action="merch.php?action=add&id=<?php echo $row["id"]; ?>">  
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
						  
       						<img src="/WeVent/bloger/theme/img/team/<?php echo $row['image']; ?>" class="img-responsive" alt="Image"> <!-- {image} = image from database -->
      						
                               <h4 class="text-info"><?php echo $row["nama"]; ?></h4>  
                               <h4 class="text-danger">Rp <?php echo $row["price"]; ?></h4>  
                               <input type="text" name="quantity" class="form-control" value="1" />  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["nama"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />  
                                
                               <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  
                          </div>  
                     </form>  
                </div>  
                <?php  
                     }  
                  
                ?>
				<div style="clear:both"></div>  
                <br />  
                <h3>Order Details</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th width="40%">Item Name</th>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="5%">Action</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>Rp <?php echo $values["item_price"]; ?></td>  
                               <td>Rp <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="merch.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          </tr>  
                          <?php  
									
									$total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">Rp <?php echo number_format($total, 2); ?></td>  
							    
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>    		
					</div>
				</div>
			</div>
			<center>
			<button type="button">Buy</button>
			</center>
<p></p>
<script type="text/javascript">
    $(document).ready(function(){
        $("button").click(function(){

            $.ajax({
                type: 'POST',
                url: 'script.php',
                success: function(data) {
                    alert(data);
                    $("p").text(data);

                }
            });
   });
});
</script>
				<!-- subscribe -->
				<div class="subscribe" id="subscribe">
					<div class="container">
						<!-- subscribe content -->
						<div class="sub-content">
							<h3>Subscribe Here for Updates</h3>
							<form role="form">
								<div class="input-group">
								
									<input type="text" class="form-control" placeholder="Email...">
										<span class="input-group-btn">
											<button class="btn btn-default" type="button" >Subscribe</button>
											<p></p>
											<script>
$(document).ready(function() {
$("button").click(function(){
  $.ajax({
    url:"script.php", //the page containing php script
    type: "POST", //request type
    success:function(result){
    alert(result);
    }
  });
});
})
</script>
										</span>
								</div><!-- /input-group -->
							</form>
						</div>
					</div>
				</div>
				<!-- subscribe end -->
			<!-- footer -->
			<?php include_once 'helper/footer.php' ?>

		</div>
		
		
		<!-- Javascript files -->
		<!-- jQuery -->
		<script src="js/jquery.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Respond JS for IE8 -->
		<script src="js/respond.min.js"></script>
		<!-- HTML5 Support for IE -->
		<script src="js/html5shiv.js"></script>
		<!-- Custom JS -->
		<script src="js/custom.js"></script>
		
	</body>	
</html>